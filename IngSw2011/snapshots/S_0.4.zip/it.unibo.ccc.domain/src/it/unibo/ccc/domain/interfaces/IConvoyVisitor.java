package it.unibo.ccc.domain.interfaces;

public interface IConvoyVisitor {

	public void visit(IConvoyVehicle cv);
	
}
