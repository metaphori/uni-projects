package it.unibo.ccc.domain.interfaces;

public interface IConvoyVehicle extends IVehicle {

	public int getID();

}
