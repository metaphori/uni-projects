package it.unibo.contaKm.view;

import java.awt.Component;

import it.unibo.contaKm.domain.IDisplay;


public interface IDisplayGui extends IDisplay{
	public Component getComponent();
}
