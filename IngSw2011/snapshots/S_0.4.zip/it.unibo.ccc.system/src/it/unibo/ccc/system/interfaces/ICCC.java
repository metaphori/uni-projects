package it.unibo.ccc.system.interfaces;

public interface ICCC extends IConvoyVehicleFacade, IConvoyChiefFacade {

}
