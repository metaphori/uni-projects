package it.unibo.contaKm.domain;

import it.unibo.system.IObservable;

public interface IObservableContaKm extends IContaKm, IObservable{

}
