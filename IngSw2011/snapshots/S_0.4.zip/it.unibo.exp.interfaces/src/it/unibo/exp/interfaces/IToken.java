package it.unibo.exp.interfaces;

public interface IToken {
	public String getName();
}
