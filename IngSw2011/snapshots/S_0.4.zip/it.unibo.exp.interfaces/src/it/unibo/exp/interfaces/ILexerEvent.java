package it.unibo.exp.interfaces;

public interface ILexerEvent {
	public void next() ;
}
