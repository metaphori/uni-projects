package it.unibo.exp.interfaces;

/**
 * @author Antonio Natali
 * @version 1.0
 */
public interface IAtomicExp extends IExp {
}
