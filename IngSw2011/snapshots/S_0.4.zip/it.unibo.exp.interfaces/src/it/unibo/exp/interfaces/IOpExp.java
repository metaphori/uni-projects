package it.unibo.exp.interfaces;

/**
 * @author Antonio Natali
 */
public interface IOpExp extends IComposedExp {
}