package it.unibo.exp.interfaces;

/**
 * @author Antonio Natali
 */
public interface INumExp extends IExp{
	public double getVal();
}
