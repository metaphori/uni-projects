package it.unibo.exp.interfaces;


public interface IParser {
	public IExp parse(String s) throws Exception;
	public IExp parse( ) throws Exception;
}
