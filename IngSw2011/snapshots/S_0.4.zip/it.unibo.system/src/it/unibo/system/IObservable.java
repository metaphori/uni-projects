package it.unibo.system;

public interface IObservable {
	public void addObserver(IObserver arg0);
}
