package it.unibo.is.interfaces;

public interface IOutputView {
	String getCurVal();
	void addOutput(String msg);
}
