package it.unibo.is.interfaces;

public interface IContactSystem {
	public void doJob() throws Exception;
	public void terminate() throws Exception;
}
