package it.unibo.exp.lexer;

public interface ISfnLexer {
	public void sfn(char ch);
}
