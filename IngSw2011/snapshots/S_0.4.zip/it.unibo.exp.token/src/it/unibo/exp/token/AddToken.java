package it.unibo.exp.token;

/**
 * @author Antonio Natali
 */
public class AddToken extends OpToken {

	public AddToken(String opName){
		super(opName);
	}

 
}