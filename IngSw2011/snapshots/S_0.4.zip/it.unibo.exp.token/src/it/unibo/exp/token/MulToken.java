package it.unibo.exp.token;

/**
 * @author Antonio Natali
 */
public class MulToken extends OpToken {

	public MulToken(String opName){
		super(opName);
	}

 
}