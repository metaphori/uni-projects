package it.unibo.exp.token;

/**
 * @author Antonio Natali
 */
public class EofToken extends WordToken {

	public EofToken(){
		super("eof");
	}

 
}