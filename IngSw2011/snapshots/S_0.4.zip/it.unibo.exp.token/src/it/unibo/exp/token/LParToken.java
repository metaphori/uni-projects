package it.unibo.exp.token;

/**
 * @author Antonio Natali
 * @version 1.0
 * @created 21-ott-2008 15.46.25
 */
public class LParToken extends WordToken {

	public LParToken(){
		super("(");
	}

 
}