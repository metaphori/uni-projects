package it.unibo.exp.token;

public abstract class OpToken extends WordToken{

	public OpToken(String name){
		super(name);
	}

 
}
