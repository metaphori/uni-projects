package it.unibo.baseEnv.androidLike;

public class Bundle {

}
