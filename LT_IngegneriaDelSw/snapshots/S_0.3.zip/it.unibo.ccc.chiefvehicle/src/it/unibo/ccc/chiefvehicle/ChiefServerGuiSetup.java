package it.unibo.ccc.chiefvehicle;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.GridLayout;
import java.awt.Panel;

import it.unibo.baseEnv.basicFrame.*;
import it.unibo.baseEnv.basicgui.input.InputPanel;
import it.unibo.ccc.domain.impl.*;
import it.unibo.ccc.domain.interfaces.*;
import it.unibo.ccc.gui.DisplayWithPanel;
import it.unibo.ccc.gui.FlagPanel;
import it.unibo.ccc.domain.SysKb;
import it.unibo.contaKm.domain.IDisplay;
import it.unibo.is.interfaces.*;
import it.unibo.supports.FactoryProtocol;
import it.unibo.supports.tcp.FactoryTcpProtocol;
import it.unibo.supports.udp.FactoryUdpProtocol;

public class ChiefServerGuiSetup {

	IBasicEnvAwt env;
	
	public void doJob(){
		init();
		configure();
		start();
	}
	
	public void init(){
		env = new EnvFrame();
		env.init();
		
		FlagPanel fp = new FlagPanel();
		
		
		//IConvoy convoy = new Convoy();
		// TODO: turn to IConvoyVehicleFacade -- need to change CCCInputControl
		String name = "ContaKmClientGuiSetup";
		FactoryTcpProtocol factory = new FactoryTcpProtocol(env,name);
		
		ConvoyCruiseControl convoy = new ConvoyCruiseControl();
		convoy.addObserver(fp);
		ConvoyProxyServer server;
		ConvoyVehicle chiefVehicle = new ConvoyVehicle(env, convoy, "ThisVehicle");
		
		
		IDisplay d1 = new DisplayWithPanel(env);
		chiefVehicle.addObserver(d1);
		IDisplay d2 =  new DisplayWithPanel(env, it.unibo.ccc.domain.SysKb.SpeedFormat.KmPerH);
		chiefVehicle.addObserver(d2);
		
		try{
			chiefVehicle.setSpeed(10); // 10 m/s = 0,01 km/s
		} catch(Exception e){}
		
		CCCInputControl ccc = new CCCInputControl(env, convoy); // interfaces to CCC system
		
		InputPanel ip = new InputPanel("Set Convoy Speed", "10", env.getOutputView(), ccc, SysKb.setSpeed);
		
		env.addCmdPanel("Commands for chief", new String[]{ SysKb.start, SysKb.stop }, ccc);
		
		Panel ppanel = new Panel();
		ppanel.setLayout( new GridLayout(4,4) );
		ppanel.add(ip);
		ppanel.add(fp);
		
		env.addPanel(ppanel);		
		
		try{
			server = new ConvoyProxyServer(env, factory, SysKb.serverPort, convoy);
		} catch(Exception exc){
			env.println("Impossibile connettere il proxy: " + exc.getMessage());
			return;
		}		
		
	}
	
	public void configure(){
		
	}
	
	public void start(){
		
	}
	
	
	public static void main(String[] args){
		ChiefServerGuiSetup setup = new ChiefServerGuiSetup();
		setup.doJob();
	}
	
}
