package it.unibo.ccc.domain.impl;

import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

import it.unibo.ccc.domain.SysKb;
import it.unibo.ccc.domain.interfaces.ICCC;
import it.unibo.ccc.domain.interfaces.IConvoy;
import it.unibo.ccc.domain.interfaces.IConvoyVehicle;
import it.unibo.ccc.domain.interfaces.IConvoyVisitor;
import it.unibo.ccc.exceptions.CannotPerformException;
import it.unibo.ccc.exceptions.InvalidArgumentException;
import it.unibo.system.IObservable;
import it.unibo.system.IObserver;

public class ConvoyCruiseControl implements IConvoy, ICCC, IObservable {
	private ArrayList<VehicleEntry> vehicles;
	private int speed;
	private boolean running;
	
	private ArrayList<IObserver> observers;
	
	public void speedNotReceived(int vehicle){
		stopConvoy();
	}
	
	public ConvoyCruiseControl(){
		vehicles = new ArrayList<VehicleEntry>();
		observers = new ArrayList<IObserver>();
		running = false;
	}
	
	@Override
	public int registerToConvoy(IConvoyVehicle v) {
		vehicles.add( new VehicleEntry(v));
		return getVehicleId(v);
	}
	
	private int getVehicleId(IConvoyVehicle v){
		for(VehicleEntry ve : vehicles){
			if(  ve.getVehicle() == v )
				return vehicles.indexOf(ve);
		}
		return -1;
	}
	
	public int getConvoySpeed(){
		return speed;
	}

	@Override
	public void startConvoy() throws CannotPerformException {
		for(VehicleEntry v : vehicles){
			try{// lascia distanza sicurezza DD metri
				Thread.sleep( (int)(1000 * SysKb.DD / getConvoySpeed())); 
			} catch(Exception e){}
			v.getVehicle().doStart();
			v.startNotifyTimer();
		}
		
		running = true;
	}

	@Override
	public void stopConvoy() {
		if(!running) return;
		
		running = false;
		
		int last = vehicles.size()-1;
		for(int i=last; i>=0; i--)
			vehicles.get(i).getVehicle().doStop();
		/*
		for(IConvoyVehicle v : vehicles.toArray()){
			v.doStop();
		}
		*/
	}

	@Override
	public void setConvoySpeed(int speed) throws InvalidArgumentException {
		for(VehicleEntry v : vehicles){
			v.getVehicle().setSpeed(speed);
			v.startNotifyTimer();
		}
		this.speed = speed;
	}

	@Override
	public void notifySpeed(int vehicle, int speed) {
		
		// speed has been notified, wait for the next notify
		vehicles.get(vehicle).startNotifyTimer();
		
		if( speed < this.speed){
			try {
				setConvoySpeed(speed);
			} catch(Exception exc){ }
		}
		else if( speed > this.speed){
			stopConvoy();
		}
	}

	@Override
	public void notifyStatus(int vehicle, boolean status) {
		System.out.println("V["+vehicle+"] IS "+status);
		vehicles.get(vehicle).setFlag(status);
		if(status == false && running){
			stopConvoy();
		}
		notifyObservers(vehicle, status);
	}
	
	// VEHICLE ENTRY ON THE LIST
	public class VehicleEntry {
		private IConvoyVehicle vehicle;
		private Timer notifyTimer;
		private TimerTask notifyTask;
		private boolean flag;
		
		public VehicleEntry(IConvoyVehicle v){
			this.vehicle = v;
			this.flag = false;
		}
		
		public boolean getFlag(){
			return flag;
		}
		
		public void setFlag(boolean status){
			flag = status;
		}
		
		public IConvoyVehicle getVehicle(){
			return vehicle;
		}
		
		public void startNotifyTimer(){
			if(notifyTask!=null)
				notifyTask.cancel();
			notifyTask = new NotifyTask(vehicle.getID());
			notifyTimer = new Timer();
			notifyTimer.schedule(notifyTask, SysKb.R*SysKb.DT);
		}
		
	}
	
	// When the timer expires, it calls speedNotReceived()
	public class NotifyTask extends TimerTask{
		private int vehicle;
		
		public NotifyTask(int vehicle){
			this.vehicle = vehicle;
		}

		@Override
		public void run() {
			speedNotReceived(vehicle);
		}
		
	}

	@Override
	public int addVehicle(IConvoyVehicle vehicle) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public IConvoyVehicle getVehicle(int position) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void accept(IConvoyVisitor cv) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void addObserver(IObserver ob) {
		observers.add(ob);
	}
		
	public void notifyObservers(int vehicle, boolean status){
		for(IObserver o : observers)
			o.update(this, vehicles.get(vehicle));
	}

	
}
