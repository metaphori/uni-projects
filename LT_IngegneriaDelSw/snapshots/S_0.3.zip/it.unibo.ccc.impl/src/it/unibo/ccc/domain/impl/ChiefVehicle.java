package it.unibo.ccc.domain.impl;

import it.unibo.ccc.domain.interfaces.ICCC;
import it.unibo.is.interfaces.IBasicEnvAwt;

public class ChiefVehicle extends ConvoyVehicle {

	public ChiefVehicle(IBasicEnvAwt env, ICCC convoy, String name){
		super(env, convoy, name);
	}
	
}
