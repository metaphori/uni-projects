package it.unibo.is.interfaces;

public interface IIntent {
	public String getAction();
	public void setAction(String action);
}
