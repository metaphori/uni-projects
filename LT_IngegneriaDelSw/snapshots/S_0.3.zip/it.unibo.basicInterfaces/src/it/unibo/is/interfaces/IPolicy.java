package it.unibo.is.interfaces;

public interface IPolicy {
	public String getPolicy();
}
