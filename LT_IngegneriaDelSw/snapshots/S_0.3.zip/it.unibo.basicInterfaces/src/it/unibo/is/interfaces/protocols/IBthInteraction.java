package it.unibo.is.interfaces.protocols;

public interface IBthInteraction extends IConnInteraction {
 	
}
