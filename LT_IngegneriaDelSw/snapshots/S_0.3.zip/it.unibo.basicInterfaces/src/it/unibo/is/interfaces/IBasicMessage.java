package it.unibo.is.interfaces;
public interface IBasicMessage {
	public String getMsgName();
	public String getMsgContent();
	public int getMsgSeqNum();
	public String basicToString();
}