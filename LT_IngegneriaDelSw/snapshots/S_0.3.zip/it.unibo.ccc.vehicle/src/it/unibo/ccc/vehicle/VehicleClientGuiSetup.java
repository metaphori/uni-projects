package it.unibo.ccc.vehicle;

import it.unibo.baseEnv.basicFrame.*;
import it.unibo.ccc.domain.SysKb;
import it.unibo.ccc.domain.impl.*;
import it.unibo.ccc.domain.interfaces.*;
import it.unibo.ccc.gui.DisplayWithPanel;
import it.unibo.contaKm.domain.IDisplay;

import it.unibo.is.interfaces.*;
import it.unibo.supports.FactoryProtocol;
import it.unibo.supports.tcp.FactoryTcpProtocol;
import it.unibo.supports.udp.FactoryUdpProtocol;

public class VehicleClientGuiSetup {

	IBasicEnvAwt env;
	
	public void doJob(){
		init();
		configure();
		start();
	}
	
	public void init(){
		env = new EnvFrame();
		env.init();
		
		//IConvoy convoy = new Convoy();
		// TODO: turn to IConvoyVehicleFacade -- need to change CCCInputControl
		String name = "ContaKmClientGuiSetup";
		FactoryProtocol factory = new FactoryTcpProtocol(env,name);
		
		ICCC convoy;
		try{
			convoy = new CCCVehicleProxy(env,factory, SysKb.hostName, SysKb.serverPort);
		} catch(Exception exc){
			env.println("Impossibile connettere il proxy: " + exc.getMessage());
			return;
		}
		ConvoyVehicle v = new ConvoyVehicle(env, convoy, "ThisVehicle");
		
		IDisplay d1 = new DisplayWithPanel(env);
		v.addObserver(d1);
		IDisplay d2 =  new DisplayWithPanel(env, SysKb.SpeedFormat.KmPerH);
		v.addObserver(d2);
		
		try{
			v.setSpeed(1); // 0.01 km/s == 10 km/h
		} catch(Exception e){}
		
		VehicleInputControl vic = new VehicleInputControl(env, v); // allows the vehicle to inc/dec speed
		env.addCmdPanel("Commands for simulation", new String[]{ SysKb.incSpeed, SysKb.decSpeed, SysKb.stop}, vic);
		
	}
	
	public void configure(){
		
	}
	
	public void start(){
		
	}
	
	
	public static void main(String[] args){
		VehicleClientGuiSetup setup = new VehicleClientGuiSetup();
		setup.doJob();
	}
	
}
