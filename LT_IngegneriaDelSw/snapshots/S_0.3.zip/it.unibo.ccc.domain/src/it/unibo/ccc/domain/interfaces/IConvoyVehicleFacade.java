package it.unibo.ccc.domain.interfaces;

public interface IConvoyVehicleFacade {

	public int registerToConvoy(IConvoyVehicle vehicle);
	
	public void notifySpeed(int vehicle, int speed);
	
	public void notifyStatus(int vehicle, boolean status);	
	
}
