package it.unibo.ccc.domain.interfaces;

import it.unibo.ccc.exceptions.CannotPerformException;
import it.unibo.ccc.exceptions.InvalidArgumentException;

public interface IConvoyChiefFacade {

	public void startConvoy() throws CannotPerformException;
	
	public void stopConvoy();
	
	public void setConvoySpeed(int speed) throws InvalidArgumentException;
	
	//public void registerAsChiefToConvoy(IConvoyVehicle chief);
	
}
