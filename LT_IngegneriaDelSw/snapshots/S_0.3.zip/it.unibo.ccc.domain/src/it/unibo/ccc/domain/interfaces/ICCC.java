package it.unibo.ccc.domain.interfaces;

public interface ICCC extends IConvoyVehicleFacade, IConvoyChiefFacade {

}
