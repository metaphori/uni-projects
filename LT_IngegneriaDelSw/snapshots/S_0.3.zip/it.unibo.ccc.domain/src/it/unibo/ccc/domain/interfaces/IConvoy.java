package it.unibo.ccc.domain.interfaces;

import it.unibo.ccc.exceptions.CannotPerformException;
import it.unibo.ccc.exceptions.InvalidArgumentException;

public interface IConvoy extends IBasicConvoy {

	public int getConvoySpeed();
	public void setConvoySpeed(int speed) throws InvalidArgumentException;
	
	public void startConvoy()  throws CannotPerformException;
	public void stopConvoy();
	
	public void accept(IConvoyVisitor cv);
	// e.g., for inspecting the vehicles' status
	
}
